package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

// Controller to handle checksum-related requests
@RestController
class ChecksumController {

    /**
     * REST endpoint to compute and return the checksum of a given input.
     *
     * @param name Optional parameter for customization. Defaults to "Stephen Bailey - CS305 Unique Data".
     * @return HTML string with the original data and its SHA-256 checksum.
     * @throws Exception If the hashing algorithm is not supported.
     */
    @GetMapping("/checksum")
    public String getChecksum(@RequestParam(value = "name", defaultValue = "Stephen Bailey - CS305 Unique Data") String name) throws Exception {
        // Generate and return the checksum of the input or default value
        return calculateChecksum(name);
    }

    /**
     * Computes the SHA-256 checksum for the provided data string.
     *
     * @param data The string to hash.
     * @return HTML string containing the original data and its checksum.
     * @throws Exception If the hashing algorithm is not supported.
     */
    private String calculateChecksum(String data) throws Exception {
        // Create a MessageDigest instance for SHA-256
        MessageDigest digest = MessageDigest.getInstance("SHA-256");

        // Compute the hash (digest) of the input data
        byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));

        // Convert the hash bytes into a hexadecimal string
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            hexString.append(String.format("%02x", b));
        }

        // Construct an HTML response with the input data and its checksum
        String response = String.format("<p>Original Data: %s</p>", data);
        response += String.format("<p>SHA-256 Checksum: %s</p>", hexString.toString());
        return response;
    }
}

